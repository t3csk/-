import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
//import java.io.*;
//import javax.imageio.*;
import java.applet.*;

public class Sample extends JFrame 
{
    public static void main(String[] args) 
    {
        Sample s = new Sample();
        s.setSize(500, 500);
        s.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        s.setVisible(true);
    }

    private ImageIcon icon;
    private JLabel lb, lb2, lb3, lb4;
    private JButton bt;
    public String[] a = new String[10];
    private AudioClip ac;
    int i = 0, j = 0;

    public Sample() 
    {
        a[0] = "x.png";
        a[1] = "x^2.png";
        a[2] = "sinx.png";
        a[3] = "cosx.png";
        a[4] = "logx.png";

        lb = new JLabel("クリックで回答欄表示 ※解答例に沿った形式で入力してください。 解答例 y=10x");
        add(lb, BorderLayout.NORTH);
        addMouseListener(new SampleMouseAdapter());
        bt = new JButton("");
        bt.addActionListener(new SampleActionListener());
        icon = new ImageIcon("x.png");
        lb2 = new JLabel();
        lb2.setBounds(60, 20, 1, 1);
        lb2.setIcon(icon);
        add(lb2);
        ac = Applet.newAudioClip(getClass().getResource("fanfare.wav"));
        addWindowListener(new SampleWindowAdapter());
        addKeyListener(new SampleKeyListener());
        lb3 = new JLabel(" ");
        lb4 = new JLabel("スペースキーで途中でやめることができます。");
        add(lb4, BorderLayout.SOUTH);
    }

    class SampleMouseAdapter extends MouseAdapter 
    {
        public void mouseClicked(MouseEvent e) 
        {
            if (i < 5) 
            {
                String ret = JOptionPane.showInputDialog(null, "解答：");

                if (i == 0) 
                {
                    if (ret.equals("y=x")) 
                    {
                        add(bt);
                        bt.setText("正解※クリックで次に進む");
                        ac.play();
                        j++;
                    } 
                    else 
                    {
                        add(bt);
                        bt.setText("不正解※クリックで次に進む");
                    }
                    i++;
                } 
                else if (i == 1) {
                    if (ret.equals("y=x^2")) 
                    {
                        add(bt);
                        bt.setText("正解※クリックで次に進む");
                        ac.play();
                        j++;
                    } 
                    else 
                    {
                        add(bt);
                        bt.setText("不正解※クリックで次に進む");
                    }
                    i++;
                } 
                else if (i == 2) {
                    if (ret.equals("y=sinx"))
                    {
                        add(bt);
                        bt.setText("正解※クリックで次に進む");
                        ac.play();
                        j++;
                    } 
                    else 
                    {
                        add(bt);
                        bt.setText("不正解※クリックで次に進む");
                    }
                    i++;
                } 
                else if (i == 3) 
                {
                    if (ret.equals("y=cosx")) 
                    {
                        add(bt);
                        bt.setText("正解※クリックで次に進む");
                        ac.play();
                        j++;
                    } 
                    else 
                    {
                        add(bt);
                        bt.setText("不正解※クリックで次に進む");
                    }
                    i++;
                } 
                else if (i == 4) 
                {
                    if (ret.equals("y=logx")) {
                        add(bt);
                        bt.setText("正解※クリックで次に進む");
                        ac.play();
                        j++;
                    } 
                    else 
                    {
                        add(bt);
                        bt.setText("不正解※クリックで次に進む");
                    }
                    i++;
                }
            }
        }
    }

    class SampleActionListener implements ActionListener 
    {
        public void actionPerformed(ActionEvent e) 
        {

            remove(bt);
            icon = new ImageIcon(a[i]);
            lb2.setIcon(icon);
            if (i >= 5) 
            {
                lb.setText("お疲れ様でした。正解数は" + j + "です。右上の×マークで閉じることで終了できます。");
                lb4.setText("");
            }
        }
    }

    class SampleWindowAdapter extends WindowAdapter 
    {
        public void windowClosing(WindowEvent e) 
        {
            System.out.println("お疲れ様でした。正解数は" + j + "です。");
        }
    }

    class SampleKeyListener extends KeyAdapter
    {
        public void keyPressed( KeyEvent e )
        {
            char keyChar = e.getKeyChar();
            String key = String.valueOf(keyChar);
            if( lb3.getText().equals(key))
            {
                System.exit(0);
            } 
        }
    }   
}