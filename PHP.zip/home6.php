<?php
session_start( );
if( !isset( $_SESSION[ "username" ] ) )
{
    header( "Location: http://".$_SERVER[ "HTTP_HOST" ]."/login6.php");
    exit;
}
?>
<?php
date_default_timezone_set('Asia/Tokyo');
$username = $_SESSION["username"];
if(isset($_POST["text"]))
{
    $txt["text"]=$_POST["text"];
    $txt["time"]=date("Y-m-d H:i:s", time());

    $line = implode("/", $txt);

    if(!file_exists("text/".$username.".txt"))
    {
        file_put_contents("text/".$username.".txt",$line."\t");
    }
    else
    {
        file_put_contents("text/".$username.".txt",$line."\t",FILE_APPEND);
    }
}
?>
<?php
if(isset($_POST["checktxt"]))
{
    $username = $_SESSION["username"];
    $n_txt = $_POST["checktxt"]; 

    $t_txt = file_get_contents("text/".$username.".txt");
    $t_part = explode("\t",$t_txt);

    $s = array_splice($t_part,$n_txt,1);

    $line = implode("\t",$t_part);
    file_put_contents("text/".$username.".txt",$line);
}
?>
<?php
if(isset($_POST["friend"]))
{
    $username = $_SESSION["username"];
    $f_name = htmlspecialchars($_POST["friend"]);

    if(!file_exists("friend/".$username.".txt"))
    {
        file_put_contents("friend/".$username.".txt",$f_name."\t");
    }
    else
    {
        file_put_contents("friend/".$username.".txt",$f_name."\t",FILE_APPEND);
    }
}
?>

<html>
<head>
<meta charset="UTF-8">
</head>
<body>
<h1>ホーム</h1>
<form method="post" action="./logout.php">
<input type="submit" value="ログアウト"/>
</form>
<form method="post" action="">
<div>
テキストを入力
<input type="text" name="text" size="100">
</div>
<div>
<input type="submit" value="つぶやく" />
</div>
<div>
フレンド登録
<input type="text" name="friend" size="100">
</div>
<div>
<input type="submit" value="フレンド登録" />
</div>
</form>
<div>
今までのつぶやき
<br>
<?php
$username = $_SESSION["username"];
if(file_exists("text/".$username.".txt"))
{
    $t_txt = file_get_contents("text/".$username.".txt");
    $t_part = explode("\t",$t_txt);
    $c_txt = count($t_part);
    for($i = $c_txt-2; $i >= 0;--$i)
    {
        $form = "<form method='post' action=''>";
        print($form.="<input type='radio' name='checktxt' value='$i'>");
        $form = "</form>";
        print($t_part[$i]."\n");
        print "<br>";
        }
}
$form = "<form method='post' action=''>";
$form.="<input type='submit' value='削除'>";
$form.="</form>";
print($form);
?>
</div>
<div>
      
他の人のつぶやき
<br>
<?php
$username = $_SESSION["username"];
if(file_exists("userdata.txt") && file_exists("friend/".$username.".txt"))
{
    $users = file_get_contents("userdata.txt");
    $u_part = explode("\t",$users);
    $c_users = count($u_part);
    $f_user = file_get_contents("friend/".$username.".txt");
    $f_part = explode("\t", $f_user);
    $c_f = count($f_part);
    for($i = $c_users-2; $i >= 0; --$i)
    {
        for($k = $c_f-2; $k >= 0; --$k)
        {
            if(strcmp($u_part[$i], $f_part[$k]) == 0)
            {
                $ot_txt = file_get_contents("text/".$u_part[$i].".txt");
                $ot_part = explode("\t",$ot_txt);
                $c_ot_txt = count($ot_part);
                print("ユーザ名：");
                print($u_part[$i]);
                print"<br>";
                for($j=$c_ot_txt-1;$j>=0;--$j)
                {
                    print($ot_part[$j]."\n");
                    print"<br>";
                }
                print "<br>";
            }
        }
    }
}
else
{
    print("他の人のつぶやきはありません");
}
?>
</div>
</body>
</html>