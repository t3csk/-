<?php
session_start();
$username = "";
$password = "";
$password2 = "";

$error_message["username"] = "";
$error_message["password"] = "";
$error_message["password2"] = "";

if( !empty($_POST) )
{
    $username = $_POST["username"] ;
    $password = $_POST[ "password"] ;
    $password2 = $_POST["password2"] ;

    if( $username === "")
    {
        $error_message["username"] = "入力必須です"; 
    }

    if( $password === "")
    {
        $error_message["password"] = "入力必須です"; 
    }

    if( $password !== $password2 )
    {
        $error_message["password2"] = "パスワードが一致しません"; 
    }

    if( $username !== "" && $password !== "" && $password === $password2 )
    {
        $username = $_POST["username"] ;
        $password = $_POST["password"] ; 
        $hash = md5( $password ) ;
        file_put_contents("data/".$username.".txt", $hash);
        file_put_contents("userdata.txt", $username."\t", FILE_APPEND);
        header("Location: login6.php") ;
        exit;
    }
}
?>
<html>
<body>
<h1>新規登録</h1>

<form method="post" action="">
<div class="error_message">
<?php
if( !empty( $error_message["username"]) )
{
    echo $error_message["username"];
}
?>
</div>
<div>
ユ ー ザ 名 ：
<input type="text" name="username" size="15"/>
</div>
<div class="error_message">
<?php
if( !empty( $error_message["password"]) )
{
    echo $error_message["password"];
}
?>
</div>
<div>
パ ス ワ ー ド ：
<input type="text" name="password" size="15"/>
</div>
<div class="error_message">
<?php
if( !empty( $error_message["password"]) )
{
    echo $error_message["password2"];
}
?>
</div>
<div>
確 認 用 パ ス ワ ー ド ：
<input type="text" name="password2" size="15"/>
</div>
<div>
<input type="submit" value="ログイン"/>
</div>
</form>
</body>
</html>