<?php
session_start ();

$error_message = "";
if(isset( $_POST["username"]) && isset( $_POST["password"]))
{
  if(file_exists("data/".$_POST["username"].".txt"))
  {
    $username = $_POST["username"];
    $password = $_POST["password"];
    $u_data = file_get_contents("data/".$username.".txt");
    $t_data = trim($u_data);
    if(md5($password) == $t_data)
    {
      $_SESSION["username"] = $_POST["username"];
      header("Location: home6.php");
      exit;
    }
    else
    {
      $error_message = "ログイン失敗" ;
    }
  }
}
?>

<html>
<head>
<meta charset="UTF-8"> </head>
<body>
<h1>ログイン</h1>
<?php
if( !empty($error_message)) 
{
  print "<p>".$error_message."</p>" ; 
}
?>
<form method="post" action=""> <div>
ユーザ名:
<input type="text" name="username" size="15" /> </div>
<div>
パスワード :
<input type="password" name="password" size="15" /> </div>
<div>
<input type="submit" value="ログイン" />
</div>
</form>
<form method="post" action="./register6.php"> <div>
<input type="submit" value="新規登録" />
</div>
</form>
</body>
</html>
